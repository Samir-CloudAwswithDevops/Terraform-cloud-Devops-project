def lambda_handler(event, context):
    return {"statusCode": 200, "body": "Hello samir for NareshIt multicloud devops!"}